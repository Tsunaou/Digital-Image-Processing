function [output] = Histogram_equalization(input_image)
%first test the image is a RGB or gray image
if numel(size(input_image)) == 3
    %this is a RGB image
    %here is just one method, if you have other ways to do the
    %equalization, you can change the following code
    r=input_image(:,:,1);
    v=input_image(:,:,2);
    b=input_image(:,:,3);
    r1 = hist_equal(r);
    v1 = hist_equal(v);
    b1 = hist_equal(b);

    rgb = cat(3,r1,v1,b1);
    output = uint8(rgb);    
else
    %this is a gray image
    gray = hist_equal(input_image);
    [output] = uint8(gray);
end

end